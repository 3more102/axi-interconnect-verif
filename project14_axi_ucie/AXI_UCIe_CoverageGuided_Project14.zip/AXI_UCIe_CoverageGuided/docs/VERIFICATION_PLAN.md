# Verification Plan

## Features and checks

| Feature | Stimulus | Checker | Coverage |
|---|---|---|---|
| AXI read | aligned reads | scoreboard | read op × address class |
| AXI write | full/partial strobes | scoreboard | write op, strobe class |
| AW/W independence | independent channel gaps | SVA + end-to-end check | regression scenario |
| AXI response | OKAY/SLVERR | scoreboard | op × response |
| Transport backpressure | `STALL_PCT` | stability SVA | response-latency class |
| Tag/opcode response | tagged endpoint responses | DUT protocol flag + monitor | transport counts |
| Error path | `0xF...` addresses | scoreboard | error address + SLVERR |
| Boundary regions | directed addresses | scoreboard | low/mid/high/error address bins |
| Reset | startup reset | reset behavior + no false transactions | assertion disable during reset |

## Sign-off criteria for the starter baseline

- zero UVM scoreboard errors;
- zero SVA assertion failures;
- no DUT `protocol_error` indication;
- all intended semantic coverage goals exercised;
- regression repeatable from a clean directory with recorded seeds.

## Coverage-guidance experiment

For each policy, use the same number of runs and the same `N_TXN` value. Record cumulative unique semantic bins after each run. Repeat with multiple seeds.

Do not compare one guided run against one random run. Report the distribution across repeated trials.

## Negative tests to add next

- wrong response tag;
- wrong response opcode;
- response timeout;
- reset while request is pending;
- transport flit corruption;
- invalid AXI alignment policy;
- burst/ID/order violations after full AXI4 extension.
