# Demo Plan

1. Run `mixed` once and show the UVM scoreboard summary, SVA status, UCDB, and semantic bins.
2. Run the adaptive controller for 7–10 iterations.
3. Show `coverage/guide_state.json`: scenario pulls, reward, and cumulative unique bins.
4. Open Questa coverage and show operation/address/response crosses.
5. Force the `errors` scenario and show deterministic `SLVERR` verification.
6. Increase `STALL_PCT` and show transport backpressure while VALID/payload stability assertions remain clean.
7. Present a plot of cumulative coverage novelty versus simulation count for random vs guided selection.

The key demonstration is not merely that tests pass; it is that the feedback loop changes which scenario is selected based on measured coverage novelty.
