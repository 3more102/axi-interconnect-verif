# Project Proposal

## Title
Coverage-Guided Intelligent Verification Framework for AXI over UCIe Interconnect

## Problem
Constrained-random verification can spend a large simulation budget repeatedly exercising already-covered behavior. The project investigates whether feedback from functional coverage can guide test selection toward uncovered AXI-over-chiplet-interconnect behaviors more efficiently.

## Objective
Build and experimentally evaluate a UVM verification framework that:

1. verifies an AXI-to-chiplet-transport bridge;
2. checks protocol invariants with SVA;
3. measures functional coverage and end-to-end data correctness;
4. feeds coverage progress back to an adaptive scenario-selection algorithm;
5. compares guided and unguided regressions using equal simulation budgets.

## Research question
Under the same number of simulations or the same wall-clock budget, does a coverage-guided scenario policy reach the defined verification coverage goals faster than uniform/random scenario selection?

## Baseline DUT
The starter DUT uses AXI4-Lite to keep the first milestone executable. It packetizes one outstanding transaction at a time into a project-defined 128-bit transaction flit. The remote endpoint returns a tagged response.

This baseline is deliberately narrower than full AXI4 and full UCIe. The research contribution is the verification feedback loop; protocol breadth is added in phases after the framework is stable.

## Verification methodology
- UVM AXI master agent.
- Transaction monitor and reference-model scoreboard.
- Functional covergroups plus semantic coverage bins.
- SVA for VALID/READY source stability and transport stability.
- Deterministic error injection and randomized backpressure.
- UCB1 coverage-guided scenario selection.

## Experiments
Compare at least:

- Uniform random scenario choice.
- Fixed hand-written regression order.
- Coverage-guided UCB1 selection.

For each strategy, run multiple independent seeds and record coverage after every simulation. Use the same transaction count and simulator options for all strategies.

## Deliverables
- RTL bridge baseline.
- UVM/SVA verification environment.
- Adaptive guidance algorithm.
- Reproducible regression scripts.
- Coverage and bug-detection experiment results.
- Final report and demo.

## Risks and controls
**Risk: full UCIe implementation is too large.** Control: use an abstract transport first, then integrate available compliant IP/BFM.

**Risk: artificial coverage gains.** Control: freeze the coverage model before comparing strategies and keep the same coverage goals for every algorithm.

**Risk: non-reproducible random results.** Control: record seeds, simulator version, command line, commit hash, and test budget.
