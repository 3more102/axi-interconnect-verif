# Architecture

## Data path

The DUT is an AXI4-Lite slave-facing bridge. AXI address/data channels are accepted, serialized into one project-defined request flit, and sent over a VALID/READY transport. A tagged response is converted back to AXI `BRESP` or `RDATA/RRESP`.

The initial bridge permits one transport transaction in flight. AXI write address and write data are latched independently so AW and W can arrive in either order.

## Remote endpoint model

The behavioral endpoint contains 1024 32-bit words. Initial contents are `0x10000000 + word_index`. Writes honor `WSTRB`. Addresses with `addr[31:28] == 4'hF` return `SLVERR`; other addresses return `OKAY`. `STALL_PCT` injects request-side backpressure.

## Verification architecture

`axi_agent` is active and contains a sequencer, driver, and monitor. The monitor publishes completed read/write transactions to both the scoreboard and coverage collector.

The scoreboard mirrors the remote memory policy and checks every completed read and response code.

The coverage collector samples SystemVerilog covergroups and also writes semantic bin names. The semantic file is intentionally simulator-independent, so the adaptive controller does not need to parse proprietary UCDB internals.

`ucie_monitor` counts transport handshakes and reports a bridge protocol-error flag.

## Intelligent feedback loop

`coverage_guide.py` implements UCB1:

`score = mean_new_bins + c * sqrt(log(total_pulls)/scenario_pulls)`

Every scenario is sampled once before UCB1 scoring starts. The reward is the count of bins not seen in any prior run. This makes the optimization target directly tied to coverage novelty.

## Extension to full AXI4

Add fields and state for:

- `AWLEN/ARLEN`, `AWSIZE/ARSIZE`, `AWBURST/ARBURST`;
- `AWID/ARID`, `BID/RID`;
- `WLAST/RLAST`;
- several outstanding tags;
- ordering scoreboard per AXI ID;
- burst legality assertions and 4-KB boundary rules;
- response reordering where permitted.

The guidance layer does not need redesign; new scenarios and semantic bins can be added to the same reward loop.
