# References

1. Arm Limited, **AMBA AXI and ACE Protocol Specification**, IHI 0022H. Official Arm Developer PDF: https://developer.arm.com/-/media/Arm%20Developer%20Community/PDF/IHI0022H_amba_axi_protocol_spec.pdf
   - Used for AXI channel structure and VALID/READY handshake requirements.

2. Arm Limited, **Introduction to AMBA AXI4**. Official Arm Developer material: https://developer.arm.com/-/media/Arm%20Developer%20Community/PDF/Learn%20the%20Architecture/102202_0100_01_Introduction_to_AMBA_AXI.pdf
   - Used as an introductory reference for the five AXI channels and handshake behavior.

3. UCIe Consortium, **Specifications**: https://www.uciexpress.org/specifications
   - Authoritative index for released UCIe specifications and public release highlights.

## Important scope note
The repository does not reproduce UCIe specification text and does not claim UCIe compliance. The 128-bit flit format in this project is a local verification abstraction. A compliant UCIe adapter/BFM should be integrated under the applicable specification/license for a production-grade implementation.
