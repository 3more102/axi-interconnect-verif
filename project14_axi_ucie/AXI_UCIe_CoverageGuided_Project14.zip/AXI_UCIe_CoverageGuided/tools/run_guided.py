#!/usr/bin/env python3
"""Compile once, then run coverage-guided Questa regressions.

Requires `vlib`, `vlog`, and `vsim` in PATH and UVM_HOME to point to a UVM
source tree containing src/uvm_pkg.sv and src/uvm_macros.svh.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

from coverage_guide import choose_next, load_state, observe, read_bins, save_state

ROOT = Path(__file__).resolve().parents[1]


def run(cmd, *, env=None):
    print("+", " ".join(map(str, cmd)))
    subprocess.run(cmd, cwd=ROOT, env=env, check=True)


def require_tool(name: str):
    if shutil.which(name) is None:
        raise SystemExit(f"Required tool not found in PATH: {name}")


def compile_design(uvm_home: Path):
    require_tool("vlib")
    require_tool("vlog")
    if not (ROOT / "work").exists():
        run(["vlib", "work"])
    src = [
        uvm_home / "src" / "uvm_pkg.sv",
        ROOT / "rtl" / "axi_ucie_pkg.sv",
        ROOT / "tb" / "axi_lite_if.sv",
        ROOT / "tb" / "ucie_stream_if.sv",
        ROOT / "rtl" / "axi_ucie_bridge.sv",
        ROOT / "rtl" / "ucie_responder_model.sv",
        ROOT / "sva" / "axi_ucie_assertions.sv",
        ROOT / "tb" / "axi_ucie_tb_pkg.sv",
        ROOT / "tb" / "tb_top.sv",
    ]
    run([
        "vlog", "-sv", f"+incdir+{uvm_home / 'src'}", "-cover", "bcesft",
        *map(str, src)
    ])


def stall_for(scenario: str) -> int:
    return {"latency": 60, "mixed": 20, "boundary": 10}.get(scenario, 5)


def simulate(scenario: str, idx: int, n_txn: int, seed: int) -> Path:
    require_tool("vsim")
    cov_dir = ROOT / "coverage"
    cov_dir.mkdir(exist_ok=True)
    bins_path = cov_dir / f"bins_{idx:02d}_{scenario}.txt"
    ucdb_path = cov_dir / f"run_{idx:02d}_{scenario}.ucdb"
    transcript = cov_dir / f"run_{idx:02d}_{scenario}.log"
    do = f"run -all; coverage save -onexit {ucdb_path.as_posix()}; quit -f"
    cmd = [
        "vsim", "-c", "-coverage", "tb_top",
        "+UVM_TESTNAME=coverage_guided_test",
        f"+SCENARIO={scenario}",
        f"+N_TXN={n_txn}",
        f"+STALL_PCT={stall_for(scenario)}",
        f"+SEED={seed}",
        f"+COV_OUT={bins_path.as_posix()}",
        "-do", do,
        "-l", str(transcript),
    ]
    run(cmd)
    return bins_path


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--iterations", type=int, default=10)
    ap.add_argument("--n-txn", type=int, default=50)
    ap.add_argument("--seed", type=int, default=20260920)
    ap.add_argument("--no-compile", action="store_true")
    ap.add_argument("--reset-state", action="store_true")
    args = ap.parse_args()

    uvm_home = os.environ.get("UVM_HOME")
    if not args.no_compile:
        if not uvm_home:
            raise SystemExit("Set UVM_HOME before compiling, e.g. path/to/uvm-1.2")
        compile_design(Path(uvm_home))

    state_path = ROOT / "coverage" / "guide_state.json"
    if args.reset_state and state_path.exists():
        state_path.unlink()
    state = load_state(state_path)

    for i in range(args.iterations):
        scenario = choose_next(state)
        bins_path = simulate(scenario, i, args.n_txn, args.seed + i)
        bins = read_bins(bins_path)
        reward = observe(state, scenario, bins)
        save_state(state_path, state)
        print(f"round={i} scenario={scenario} reward(new_bins)={reward} total_bins={len(state['global_bins'])}")
        if reward == 0 and i >= 6:
            print("No new bins this round; continuing policy exploration.")

    print(json.dumps(state, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
