#!/usr/bin/env python3
"""Coverage-guided scenario selector.

Uses UCB1 (multi-armed bandit) where reward is the number of *new* functional
coverage bins contributed by the last scenario. The policy is deterministic
for equal scores (scenario-list order), easy to audit, and does not require
cloud AI services.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Dict, Iterable, List, Set

SCENARIOS: List[str] = [
    "mixed",
    "boundary",
    "errors",
    "partial_strobe",
    "latency",
    "read_heavy",
    "write_heavy",
]


def default_state() -> dict:
    return {
        "global_bins": [],
        "rounds": 0,
        "scenarios": {
            name: {"pulls": 0, "reward_sum": 0.0, "last_reward": 0.0}
            for name in SCENARIOS
        },
    }


def load_state(path: Path) -> dict:
    if not path.exists():
        return default_state()
    state = json.loads(path.read_text())
    for s in SCENARIOS:
        state.setdefault("scenarios", {}).setdefault(
            s, {"pulls": 0, "reward_sum": 0.0, "last_reward": 0.0}
        )
    state.setdefault("global_bins", [])
    state.setdefault("rounds", 0)
    return state


def save_state(path: Path, state: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(state, indent=2, sort_keys=True) + "\n")


def read_bins(path: Path) -> Set[str]:
    if not path.exists():
        raise FileNotFoundError(f"coverage-bin file not found: {path}")
    return {
        line.strip()
        for line in path.read_text().splitlines()
        if line.strip() and not line.lstrip().startswith("#")
    }


def observe(state: dict, scenario: str, bins: Iterable[str]) -> int:
    if scenario not in state["scenarios"]:
        raise ValueError(f"unknown scenario: {scenario}")
    global_bins = set(state["global_bins"])
    run_bins = set(bins)
    new_bins = run_bins - global_bins
    reward = len(new_bins)

    stats = state["scenarios"][scenario]
    stats["pulls"] += 1
    stats["reward_sum"] += float(reward)
    stats["last_reward"] = float(reward)
    state["rounds"] += 1
    state["global_bins"] = sorted(global_bins | run_bins)
    return reward


def choose_next(state: dict, exploration: float = 1.4) -> str:
    # Force one sample from every scenario first.
    for s in SCENARIOS:
        if state["scenarios"][s]["pulls"] == 0:
            return s

    total = max(1, sum(v["pulls"] for v in state["scenarios"].values()))
    best_s = SCENARIOS[0]
    best_score = float("-inf")
    for s in SCENARIOS:
        st = state["scenarios"][s]
        mean = st["reward_sum"] / st["pulls"]
        bonus = exploration * math.sqrt(math.log(total) / st["pulls"])
        score = mean + bonus
        if score > best_score:
            best_score = score
            best_s = s
    return best_s


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--state", type=Path, default=Path("coverage/guide_state.json"))
    ap.add_argument("--observe-bins", type=Path)
    ap.add_argument("--scenario")
    ap.add_argument("--choose", action="store_true")
    ap.add_argument("--exploration", type=float, default=1.4)
    ap.add_argument("--json", action="store_true", help="print machine-readable output")
    args = ap.parse_args()

    state = load_state(args.state)
    reward = None
    if args.observe_bins:
        if not args.scenario:
            ap.error("--scenario is required with --observe-bins")
        reward = observe(state, args.scenario, read_bins(args.observe_bins))
        save_state(args.state, state)

    next_s = choose_next(state, args.exploration) if args.choose else None
    if args.json:
        print(json.dumps({
            "reward": reward,
            "next_scenario": next_s,
            "global_bins": len(state["global_bins"]),
            "rounds": state["rounds"],
        }))
    else:
        if reward is not None:
            print(f"new_bins={reward} total_bins={len(state['global_bins'])}")
        if next_s is not None:
            print(next_s)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
