`timescale 1ns/1ps

module axi_ucie_assertions(
  input logic clk,
  input logic rst_n,
  input logic [31:0] awaddr,
  input logic awvalid, awready,
  input logic [31:0] wdata,
  input logic [3:0] wstrb,
  input logic wvalid, wready,
  input logic [1:0] bresp,
  input logic bvalid, bready,
  input logic [31:0] araddr,
  input logic arvalid, arready,
  input logic [31:0] rdata,
  input logic [1:0] rresp,
  input logic rvalid, rready,
  input logic [127:0] tx_flit,
  input logic tx_valid, tx_ready,
  input logic [127:0] rx_flit,
  input logic rx_valid, rx_ready
);
  default clocking cb @(posedge clk); endclocking
  default disable iff (!rst_n);

  // AXI rule: source keeps VALID asserted and payload stable until handshake.
  ap_aw_stable: assert property (awvalid && !awready |=> awvalid && $stable(awaddr));
  ap_w_stable:  assert property (wvalid  && !wready  |=> wvalid  && $stable({wdata,wstrb}));
  ap_ar_stable: assert property (arvalid && !arready |=> arvalid && $stable(araddr));
  ap_b_stable:  assert property (bvalid  && !bready  |=> bvalid  && $stable(bresp));
  ap_r_stable:  assert property (rvalid  && !rready  |=> rvalid  && $stable({rdata,rresp}));

  ap_tx_stable: assert property (tx_valid && !tx_ready |=> tx_valid && $stable(tx_flit));
  ap_rx_stable: assert property (rx_valid && !rx_ready |=> rx_valid && $stable(rx_flit));

  // Bounded progress assumptions for this verification model, not AXI protocol mandates.
  cp_write: cover property (awvalid && awready ##[0:8] wvalid && wready ##[1:30] bvalid && bready);
  cp_read:  cover property (arvalid && arready ##[1:30] rvalid && rready);
endmodule
