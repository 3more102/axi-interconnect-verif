from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))

from coverage_guide import SCENARIOS, choose_next, default_state, observe


def test_initial_exploration_order():
    s = default_state()
    assert choose_next(s) == SCENARIOS[0]
    observe(s, SCENARIOS[0], {"a"})
    assert choose_next(s) == SCENARIOS[1]


def test_reward_counts_only_new_bins():
    s = default_state()
    assert observe(s, "mixed", {"a", "b"}) == 2
    assert observe(s, "mixed", {"b", "c"}) == 1
    assert set(s["global_bins"]) == {"a", "b", "c"}


def test_policy_returns_known_scenario():
    s = default_state()
    for name in SCENARIOS:
        observe(s, name, {f"bin.{name}"})
    assert choose_next(s) in SCENARIOS
