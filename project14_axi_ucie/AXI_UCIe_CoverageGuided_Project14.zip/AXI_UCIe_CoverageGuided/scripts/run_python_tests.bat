@echo off
cd /d %~dp0\..
python -m pytest -q tests\test_coverage_guide.py
