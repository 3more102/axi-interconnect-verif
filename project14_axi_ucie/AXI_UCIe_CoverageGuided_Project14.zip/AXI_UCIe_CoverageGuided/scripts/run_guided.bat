@echo off
cd /d %~dp0\..
if "%UVM_HOME%"=="" (
  echo ERROR: set UVM_HOME to a UVM source tree, for example C:\path\to\uvm-1.2
  exit /b 1
)
python tools\run_guided.py --iterations 10 --n-txn 50 --reset-state
