interface axi_lite_if(input logic aclk, input logic aresetn);
  logic [31:0] awaddr;
  logic awvalid, awready;
  logic [31:0] wdata;
  logic [3:0]  wstrb;
  logic wvalid, wready;
  logic [1:0]  bresp;
  logic bvalid, bready;
  logic [31:0] araddr;
  logic arvalid, arready;
  logic [31:0] rdata;
  logic [1:0]  rresp;
  logic rvalid, rready;

  clocking drv_cb @(posedge aclk);
    default input #1step output #0;
    output awaddr, awvalid, wdata, wstrb, wvalid, bready;
    output araddr, arvalid, rready;
    input  awready, wready, bresp, bvalid;
    input  arready, rdata, rresp, rvalid;
  endclocking

  clocking mon_cb @(posedge aclk);
    default input #1step;
    input awaddr, awvalid, awready;
    input wdata, wstrb, wvalid, wready;
    input bresp, bvalid, bready;
    input araddr, arvalid, arready;
    input rdata, rresp, rvalid, rready;
  endclocking
endinterface
