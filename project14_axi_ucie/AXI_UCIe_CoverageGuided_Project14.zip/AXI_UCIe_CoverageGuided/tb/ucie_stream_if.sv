interface ucie_stream_if(input logic clk, input logic rst_n);
  logic [127:0] tx_flit;
  logic tx_valid, tx_ready;
  logic [127:0] rx_flit;
  logic rx_valid, rx_ready;
  logic protocol_error;

  clocking mon_cb @(posedge clk);
    default input #1step;
    input tx_flit, tx_valid, tx_ready;
    input rx_flit, rx_valid, rx_ready;
    input protocol_error;
  endclocking
endinterface
