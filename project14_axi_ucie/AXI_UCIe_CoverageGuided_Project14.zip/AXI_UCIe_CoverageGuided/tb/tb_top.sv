`timescale 1ns/1ps

module tb_top;
  import uvm_pkg::*;
  import axi_ucie_pkg::*;
  import axi_ucie_tb_pkg::*;

  logic clk=0;
  logic rst_n=0;
  always #5 clk = ~clk;

  axi_lite_if axi_if(clk, rst_n);
  ucie_stream_if ucie_if(clk, rst_n);

  axi_ucie_bridge dut (
    .aclk(clk), .aresetn(rst_n),
    .s_axi_awaddr(axi_if.awaddr), .s_axi_awvalid(axi_if.awvalid), .s_axi_awready(axi_if.awready),
    .s_axi_wdata(axi_if.wdata), .s_axi_wstrb(axi_if.wstrb), .s_axi_wvalid(axi_if.wvalid), .s_axi_wready(axi_if.wready),
    .s_axi_bresp(axi_if.bresp), .s_axi_bvalid(axi_if.bvalid), .s_axi_bready(axi_if.bready),
    .s_axi_araddr(axi_if.araddr), .s_axi_arvalid(axi_if.arvalid), .s_axi_arready(axi_if.arready),
    .s_axi_rdata(axi_if.rdata), .s_axi_rresp(axi_if.rresp), .s_axi_rvalid(axi_if.rvalid), .s_axi_rready(axi_if.rready),
    .ucie_tx_flit(ucie_if.tx_flit), .ucie_tx_valid(ucie_if.tx_valid), .ucie_tx_ready(ucie_if.tx_ready),
    .ucie_rx_flit(ucie_if.rx_flit), .ucie_rx_valid(ucie_if.rx_valid), .ucie_rx_ready(ucie_if.rx_ready),
    .protocol_error(ucie_if.protocol_error)
  );

  ucie_responder_model remote_ep (
    .clk(clk), .rst_n(rst_n),
    .rx_flit(ucie_if.tx_flit), .rx_valid(ucie_if.tx_valid), .rx_ready(ucie_if.tx_ready),
    .tx_flit(ucie_if.rx_flit), .tx_valid(ucie_if.rx_valid), .tx_ready(ucie_if.rx_ready)
  );

  axi_ucie_assertions sva (
    .clk(clk), .rst_n(rst_n),
    .awaddr(axi_if.awaddr), .awvalid(axi_if.awvalid), .awready(axi_if.awready),
    .wdata(axi_if.wdata), .wstrb(axi_if.wstrb), .wvalid(axi_if.wvalid), .wready(axi_if.wready),
    .bresp(axi_if.bresp), .bvalid(axi_if.bvalid), .bready(axi_if.bready),
    .araddr(axi_if.araddr), .arvalid(axi_if.arvalid), .arready(axi_if.arready),
    .rdata(axi_if.rdata), .rresp(axi_if.rresp), .rvalid(axi_if.rvalid), .rready(axi_if.rready),
    .tx_flit(ucie_if.tx_flit), .tx_valid(ucie_if.tx_valid), .tx_ready(ucie_if.tx_ready),
    .rx_flit(ucie_if.rx_flit), .rx_valid(ucie_if.rx_valid), .rx_ready(ucie_if.rx_ready)
  );

  initial begin
    repeat (8) @(posedge clk);
    rst_n <= 1;
  end

  initial begin
    uvm_config_db#(virtual axi_lite_if)::set(null, "uvm_test_top.env.agent.*", "vif", axi_if);
    uvm_config_db#(virtual ucie_stream_if)::set(null, "uvm_test_top.env.ucie_mon", "vif", ucie_if);
    run_test();
  end
endmodule
