package axi_ucie_tb_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  typedef enum bit {AXI_READ=0, AXI_WRITE=1} axi_dir_e;

  class axi_txn extends uvm_sequence_item;
    rand axi_dir_e dir;
    rand bit [31:0] addr;
    rand bit [31:0] data;
    rand bit [3:0]  strb;
    rand int unsigned aw_gap;
    rand int unsigned w_gap;
    rand int unsigned ar_gap;
    rand int unsigned rsp_ready_gap;

    bit [31:0] rdata;
    bit [1:0]  resp;
    int unsigned req_wait;
    int unsigned rsp_wait;

    constraint c_gaps { aw_gap inside {[0:5]}; w_gap inside {[0:5]}; ar_gap inside {[0:5]}; rsp_ready_gap inside {[0:5]}; }
    constraint c_align { addr[1:0] == 2'b00; }
    constraint c_strb  { if (dir == AXI_WRITE) strb != 4'b0000; }

    `uvm_object_utils_begin(axi_txn)
      `uvm_field_enum(axi_dir_e, dir, UVM_DEFAULT)
      `uvm_field_int(addr, UVM_HEX)
      `uvm_field_int(data, UVM_HEX)
      `uvm_field_int(strb, UVM_HEX)
      `uvm_field_int(aw_gap, UVM_DEC)
      `uvm_field_int(w_gap, UVM_DEC)
      `uvm_field_int(ar_gap, UVM_DEC)
      `uvm_field_int(rsp_ready_gap, UVM_DEC)
      `uvm_field_int(rdata, UVM_HEX)
      `uvm_field_int(resp, UVM_HEX)
      `uvm_field_int(req_wait, UVM_DEC)
      `uvm_field_int(rsp_wait, UVM_DEC)
    `uvm_object_utils_end

    function new(string name="axi_txn"); super.new(name); endfunction
  endclass

  class axi_sequencer extends uvm_sequencer #(axi_txn);
    `uvm_component_utils(axi_sequencer)
    function new(string name, uvm_component parent); super.new(name,parent); endfunction
  endclass

  class axi_driver extends uvm_driver #(axi_txn);
    `uvm_component_utils(axi_driver)
    virtual axi_lite_if vif;

    function new(string name, uvm_component parent); super.new(name,parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(virtual axi_lite_if)::get(this, "", "vif", vif))
        `uvm_fatal("NOVIF", "axi_driver: virtual interface not set")
    endfunction

    task reset_master();
      vif.awvalid = 0; vif.awaddr = '0;
      vif.wvalid  = 0; vif.wdata = '0; vif.wstrb = '0;
      vif.bready  = 0;
      vif.arvalid = 0; vif.araddr = '0;
      vif.rready  = 0;
    endtask

    task drive_write(axi_txn tr);
      fork
        begin
          repeat (tr.aw_gap) @(vif.drv_cb);
          vif.drv_cb.awaddr  <= tr.addr;
          vif.drv_cb.awvalid <= 1;
          do @(vif.drv_cb); while (!vif.drv_cb.awready);
          vif.drv_cb.awvalid <= 0;
        end
        begin
          repeat (tr.w_gap) @(vif.drv_cb);
          vif.drv_cb.wdata  <= tr.data;
          vif.drv_cb.wstrb  <= tr.strb;
          vif.drv_cb.wvalid <= 1;
          do @(vif.drv_cb); while (!vif.drv_cb.wready);
          vif.drv_cb.wvalid <= 0;
        end
      join
      repeat (tr.rsp_ready_gap) @(vif.drv_cb);
      vif.drv_cb.bready <= 1;
      do @(vif.drv_cb); while (!vif.drv_cb.bvalid);
      tr.resp = vif.drv_cb.bresp;
      vif.drv_cb.bready <= 0;
    endtask

    task drive_read(axi_txn tr);
      repeat (tr.ar_gap) @(vif.drv_cb);
      vif.drv_cb.araddr  <= tr.addr;
      vif.drv_cb.arvalid <= 1;
      do @(vif.drv_cb); while (!vif.drv_cb.arready);
      vif.drv_cb.arvalid <= 0;
      repeat (tr.rsp_ready_gap) @(vif.drv_cb);
      vif.drv_cb.rready <= 1;
      do @(vif.drv_cb); while (!vif.drv_cb.rvalid);
      tr.rdata = vif.drv_cb.rdata;
      tr.resp  = vif.drv_cb.rresp;
      vif.drv_cb.rready <= 0;
    endtask

    task run_phase(uvm_phase phase);
      axi_txn tr;
      reset_master();
      wait (vif.aresetn === 1'b1);
      forever begin
        seq_item_port.get_next_item(tr);
        if (tr.dir == AXI_WRITE) drive_write(tr);
        else                     drive_read(tr);
        seq_item_port.item_done();
      end
    endtask
  endclass

  class axi_monitor extends uvm_component;
    `uvm_component_utils(axi_monitor)
    virtual axi_lite_if vif;
    uvm_analysis_port #(axi_txn) ap;

    bit aw_seen, w_seen, ar_seen;
    bit [31:0] awaddr_q, wdata_q, araddr_q;
    bit [3:0] wstrb_q;
    int wr_req_wait, rd_req_wait, wr_rsp_wait, rd_rsp_wait;

    function new(string name, uvm_component parent);
      super.new(name,parent);
      ap = new("ap", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(virtual axi_lite_if)::get(this, "", "vif", vif))
        `uvm_fatal("NOVIF", "axi_monitor: virtual interface not set")
    endfunction

    task run_phase(uvm_phase phase);
      axi_txn tr;
      aw_seen=0; w_seen=0; ar_seen=0;
      forever begin
        @(vif.mon_cb);
        if (!vif.aresetn) begin
          aw_seen=0; w_seen=0; ar_seen=0;
          wr_req_wait=0; rd_req_wait=0; wr_rsp_wait=0; rd_rsp_wait=0;
          continue;
        end

        if (vif.mon_cb.awvalid && !vif.mon_cb.awready) wr_req_wait++;
        if (vif.mon_cb.wvalid  && !vif.mon_cb.wready)  wr_req_wait++;
        if (vif.mon_cb.arvalid && !vif.mon_cb.arready) rd_req_wait++;
        if ((aw_seen && w_seen) && !vif.mon_cb.bvalid) wr_rsp_wait++;
        if (ar_seen && !vif.mon_cb.rvalid) rd_rsp_wait++;

        if (vif.mon_cb.awvalid && vif.mon_cb.awready) begin
          aw_seen = 1; awaddr_q = vif.mon_cb.awaddr;
        end
        if (vif.mon_cb.wvalid && vif.mon_cb.wready) begin
          w_seen = 1; wdata_q = vif.mon_cb.wdata; wstrb_q = vif.mon_cb.wstrb;
        end
        if (vif.mon_cb.arvalid && vif.mon_cb.arready) begin
          ar_seen = 1; araddr_q = vif.mon_cb.araddr;
        end

        if (vif.mon_cb.bvalid && vif.mon_cb.bready && aw_seen && w_seen) begin
          tr = axi_txn::type_id::create("wr_mon_tr");
          tr.dir = AXI_WRITE; tr.addr = awaddr_q; tr.data = wdata_q; tr.strb = wstrb_q;
          tr.resp = vif.mon_cb.bresp; tr.req_wait = wr_req_wait; tr.rsp_wait = wr_rsp_wait;
          ap.write(tr);
          aw_seen=0; w_seen=0; wr_req_wait=0; wr_rsp_wait=0;
        end

        if (vif.mon_cb.rvalid && vif.mon_cb.rready && ar_seen) begin
          tr = axi_txn::type_id::create("rd_mon_tr");
          tr.dir = AXI_READ; tr.addr = araddr_q; tr.rdata = vif.mon_cb.rdata; tr.strb = 4'h0;
          tr.resp = vif.mon_cb.rresp; tr.req_wait = rd_req_wait; tr.rsp_wait = rd_rsp_wait;
          ap.write(tr);
          ar_seen=0; rd_req_wait=0; rd_rsp_wait=0;
        end
      end
    endtask
  endclass

  class axi_agent extends uvm_agent;
    `uvm_component_utils(axi_agent)
    axi_sequencer sqr;
    axi_driver drv;
    axi_monitor mon;

    function new(string name, uvm_component parent); super.new(name,parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      sqr = axi_sequencer::type_id::create("sqr", this);
      drv = axi_driver::type_id::create("drv", this);
      mon = axi_monitor::type_id::create("mon", this);
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      drv.seq_item_port.connect(sqr.seq_item_export);
    endfunction
  endclass

  class axi_scoreboard extends uvm_component;
    `uvm_component_utils(axi_scoreboard)
    uvm_analysis_imp #(axi_txn, axi_scoreboard) imp;
    bit [31:0] mem [0:1023];
    int unsigned checked, errors;

    function new(string name, uvm_component parent);
      super.new(name,parent);
      imp = new("imp", this);
      for (int i=0; i<1024; i++) mem[i] = 32'h1000_0000 + i;
    endfunction

    function void write(axi_txn tr);
      int unsigned idx = tr.addr[11:2];
      bit is_err = (tr.addr[31:28] == 4'hF);
      checked++;
      if (is_err) begin
        if (tr.resp != 2'b10) begin
          errors++;
          `uvm_error("SCB", $sformatf("Expected SLVERR @0x%08h, got %0b", tr.addr, tr.resp))
        end
        return;
      end
      if (tr.resp != 2'b00) begin
        errors++;
        `uvm_error("SCB", $sformatf("Unexpected response %0b @0x%08h", tr.resp, tr.addr))
      end
      if (tr.dir == AXI_WRITE) begin
        if (tr.strb[0]) mem[idx][7:0]   = tr.data[7:0];
        if (tr.strb[1]) mem[idx][15:8]  = tr.data[15:8];
        if (tr.strb[2]) mem[idx][23:16] = tr.data[23:16];
        if (tr.strb[3]) mem[idx][31:24] = tr.data[31:24];
      end else begin
        if (tr.rdata !== mem[idx]) begin
          errors++;
          `uvm_error("SCB", $sformatf("Read mismatch @0x%08h exp=0x%08h got=0x%08h", tr.addr, mem[idx], tr.rdata))
        end
      end
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SCB", $sformatf("checked=%0d errors=%0d", checked, errors), UVM_LOW)
    endfunction
  endclass

  class coverage_collector extends uvm_component;
    `uvm_component_utils(coverage_collector)
    uvm_analysis_imp #(axi_txn, coverage_collector) imp;
    string bins[string];
    int fd;
    string outfile;

    covergroup cg with function sample(axi_txn tr);
      option.per_instance = 1;
      cp_op: coverpoint tr.dir { bins rd={AXI_READ}; bins wr={AXI_WRITE}; }
      cp_resp: coverpoint tr.resp { bins okay={2'b00}; bins slverr={2'b10}; illegal_bins unsupported=default; }
      cp_addr: coverpoint tr.addr[31:28] {
        bins low={[0:3]}; bins mid={[4:11]}; bins high={[12:14]}; bins err={15};
      }
      cp_strb: coverpoint tr.strb iff (tr.dir==AXI_WRITE) {
        bins full={4'hF}; bins single[] = {4'h1,4'h2,4'h4,4'h8}; bins partial=default;
      }
      cp_rspwait: coverpoint tr.rsp_wait { bins short={[1:3]}; bins medium={[4:10]}; bins long={[11:65535]}; }
      op_x_resp: cross cp_op, cp_resp;
      op_x_addr: cross cp_op, cp_addr;
    endgroup

    function new(string name, uvm_component parent);
      super.new(name,parent);
      imp = new("imp", this);
      cg = new();
      outfile = "coverage/bins_seen.txt";
    endfunction

    function void build_phase(uvm_phase phase);
      string tmp;
      super.build_phase(phase);
      if ($value$plusargs("COV_OUT=%s", tmp)) outfile = tmp;
    endfunction

    function void mark(string s); bins[s] = s; endfunction

    function void write(axi_txn tr);
      string op, ac, rp, st, rq, rs;
      cg.sample(tr);
      op = (tr.dir==AXI_WRITE) ? "op.write" : "op.read";
      if (tr.addr[31:28] <= 4'h3) ac="addr.low";
      else if (tr.addr[31:28] <= 4'hB) ac="addr.mid";
      else if (tr.addr[31:28] <= 4'hE) ac="addr.high";
      else ac="addr.error";
      rp = (tr.resp==2'b00) ? "resp.okay" : ((tr.resp==2'b10) ? "resp.slverr" : "resp.other");
      if (tr.dir==AXI_WRITE) begin
        if (tr.strb==4'hF) st="strb.full";
        else if ($onehot(tr.strb)) st="strb.single";
        else st="strb.partial";
        mark(st);
      end
      rq = (tr.req_wait==0) ? "reqwait.zero" : ((tr.req_wait<=3) ? "reqwait.short" : "reqwait.long");
      rs = (tr.rsp_wait==0) ? "rspwait.zero" : ((tr.rsp_wait<=3) ? "rspwait.short" : "rspwait.long");
      mark(op); mark(ac); mark(rp); mark(rq); mark(rs);
      mark({op,"|",ac});
      mark({op,"|",rp});
    endfunction

    function void report_phase(uvm_phase phase);
      fd = $fopen(outfile, "w");
      if (fd == 0) begin
        `uvm_error("COV", $sformatf("Cannot open %s", outfile))
        return;
      end
      foreach (bins[k]) $fdisplay(fd, "%s", k);
      $fclose(fd);
      `uvm_info("COV", $sformatf("functional_coverage=%0.2f%% bins_written=%0d file=%s", cg.get_inst_coverage(), bins.num(), outfile), UVM_LOW)
    endfunction
  endclass

  class ucie_monitor extends uvm_component;
    `uvm_component_utils(ucie_monitor)
    virtual ucie_stream_if vif;
    int unsigned tx_count, rx_count;
    function new(string name, uvm_component parent); super.new(name,parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(virtual ucie_stream_if)::get(this, "", "vif", vif))
        `uvm_fatal("NOVIF", "ucie_monitor: virtual interface not set")
    endfunction
    task run_phase(uvm_phase phase);
      forever begin
        @(vif.mon_cb);
        if (vif.mon_cb.tx_valid && vif.mon_cb.tx_ready) tx_count++;
        if (vif.mon_cb.rx_valid && vif.mon_cb.rx_ready) rx_count++;
        if (vif.mon_cb.protocol_error)
          `uvm_error("UCIE", "Bridge flagged response opcode/tag mismatch")
      end
    endtask
    function void report_phase(uvm_phase phase);
      `uvm_info("UCIE", $sformatf("tx_flits=%0d rx_flits=%0d", tx_count, rx_count), UVM_LOW)
    endfunction
  endclass

  class axi_ucie_env extends uvm_env;
    `uvm_component_utils(axi_ucie_env)
    axi_agent agent;
    axi_scoreboard scb;
    coverage_collector cov;
    ucie_monitor ucie_mon;
    function new(string name, uvm_component parent); super.new(name,parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agent = axi_agent::type_id::create("agent", this);
      scb = axi_scoreboard::type_id::create("scb", this);
      cov = coverage_collector::type_id::create("cov", this);
      ucie_mon = ucie_monitor::type_id::create("ucie_mon", this);
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      agent.mon.ap.connect(scb.imp);
      agent.mon.ap.connect(cov.imp);
    endfunction
  endclass

  class scenario_sequence extends uvm_sequence #(axi_txn);
    `uvm_object_utils(scenario_sequence)
    string scenario="mixed";
    int n_txn=40;

    function new(string name="scenario_sequence"); super.new(name); endfunction

    task emit(axi_dir_e d, bit [31:0] a, bit [31:0] dat='0, bit[3:0] s=4'hF,
              int ag=0, int wg=0, int rg=0, int bg=0);
      axi_txn tr = axi_txn::type_id::create("tr");
      start_item(tr);
      tr.dir=d; tr.addr=a; tr.data=dat; tr.strb=s;
      tr.aw_gap=ag; tr.w_gap=wg; tr.ar_gap=rg; tr.rsp_ready_gap=bg;
      finish_item(tr);
    endtask

    task body();
      string tmp;
      if ($value$plusargs("SCENARIO=%s", tmp)) scenario = tmp;
      void'($value$plusargs("N_TXN=%d", n_txn));
      `uvm_info("SEQ", $sformatf("scenario=%s n_txn=%0d", scenario, n_txn), UVM_LOW)

      if (scenario == "boundary") begin
        bit [31:0] a[8] = '{32'h0000_0000,32'h0000_0004,32'h0000_0FFC,32'h4000_0000,
                            32'h8000_0000,32'hC000_0000,32'hE000_0000,32'hF000_0000};
        foreach (a[i]) begin
          emit(AXI_WRITE,a[i],32'hA5A50000+i,4'hF,i%3,(i+1)%3,0,i%4);
          emit(AXI_READ,a[i],0,0,0,0,i%3,(i+2)%4);
        end
      end else begin
        for (int i=0; i<n_txn; i++) begin
          axi_txn tr = axi_txn::type_id::create($sformatf("tr_%0d",i));
          start_item(tr);
          case (scenario)
            "read_heavy": begin
              if (!tr.randomize() with { dir dist {AXI_READ:=8,AXI_WRITE:=2}; addr[31:28] inside {[0:14]}; })
                `uvm_fatal("RAND", "randomize failed")
            end
            "write_heavy": begin
              if (!tr.randomize() with { dir dist {AXI_READ:=2,AXI_WRITE:=8}; addr[31:28] inside {[0:14]}; })
                `uvm_fatal("RAND", "randomize failed")
            end
            "errors": begin
              if (!tr.randomize() with { addr[31:28] == 4'hF; })
                `uvm_fatal("RAND", "randomize failed")
            end
            "partial_strobe": begin
              if (!tr.randomize() with { dir == AXI_WRITE; strb inside {4'h1,4'h2,4'h4,4'h8,4'h3,4'hC,4'h5,4'hA}; addr[31:28] inside {[0:14]}; })
                `uvm_fatal("RAND", "randomize failed")
            end
            "latency": begin
              if (!tr.randomize() with { aw_gap inside {[3:5]}; w_gap inside {[3:5]}; ar_gap inside {[3:5]}; rsp_ready_gap inside {[3:5]}; })
                `uvm_fatal("RAND", "randomize failed")
            end
            default: begin
              if (!tr.randomize() with { addr[31:28] dist {[0:3]:=3,[4:11]:=3,[12:14]:=2,15:=1}; })
                `uvm_fatal("RAND", "randomize failed")
            end
          endcase
          finish_item(tr);
        end
      end
    endtask
  endclass

  class coverage_guided_test extends uvm_test;
    `uvm_component_utils(coverage_guided_test)
    axi_ucie_env env;
    function new(string name, uvm_component parent); super.new(name,parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      env = axi_ucie_env::type_id::create("env", this);
    endfunction
    task run_phase(uvm_phase phase);
      scenario_sequence seq = scenario_sequence::type_id::create("seq");
      phase.raise_objection(this);
      seq.start(env.agent.sqr);
      repeat (20) @(posedge env.agent.drv.vif.aclk);
      phase.drop_objection(this);
    endtask
  endclass

endpackage
