# Project 14 — Coverage-Guided Intelligent Verification Framework for AXI over UCIe Interconnect

A graduation-project starter implementation for **coverage-guided verification of an AXI-to-UCIe transaction bridge** using **SystemVerilog, UVM, SVA, Questa, functional coverage, and an adaptive Python scenario selector**.

## What is implemented

- Synthesizable baseline DUT: **AXI4-Lite slave → 128-bit transaction-flit tunnel**.
- Abstract UCIe streaming transport with request/response tags and backpressure.
- Behavioral remote endpoint with memory, response generation, error injection region, and link stalls.
- UVM master agent, monitor, scoreboard, functional coverage collector, and scenario sequences.
- SVA for AXI VALID/READY stability and transport VALID/READY stability.
- Coverage-guided controller using **UCB1 multi-armed-bandit selection**. Reward = number of previously unseen semantic coverage bins found by a scenario.
- Questa UCDB generation plus a simulator-independent semantic coverage log.
- Python unit tests for the coverage-guidance algorithm.

> **Scope boundary:** this repository does **not** claim full UCIe protocol/PHY compliance. UCIe is modeled as an abstract streaming transaction transport so the verification research can be developed without reproducing proprietary/evaluation-copy specification content. Replace the transport adapter/model with your spec-compliant UCIe IP or BFM when available. The baseline AXI side is AXI4-Lite; full AXI4 burst/ID support is an explicit Phase-2 extension.

## Architecture

```text
   UVM AXI master
        |
        v
 +------------------+       128-bit abstract        +------------------+
 | AXI→UCIe bridge  | ===== transaction flits =====> | remote endpoint  |
 |      DUT         | <==== response flits ========= | memory/error BFM |
 +------------------+                                +------------------+
      |       |
      |       +---- SVA
      |
      +---- AXI monitor ----+---- scoreboard
                            +---- coverage collector ---- bins_seen.txt
                                                         |
                                                         v
                                                   UCB1 guide
                                                         |
                                               next scenario choice
```

## Baseline packet format

The internal 128-bit verification flit is intentionally project-defined:

| Bits | Meaning |
|---|---|
| 127:124 | opcode: write request, read request, write response, read response |
| 123:92 | 32-bit address |
| 91:60 | 32-bit write/read data |
| 59:56 | AXI write strobe |
| 55:54 | AXI response |
| 53:46 | transaction tag |
| 45:0 | reserved |

This format is a **verification abstraction**, not a UCIe wire-format definition.

## Verification scenarios

`mixed`, `boundary`, `errors`, `partial_strobe`, `latency`, `read_heavy`, and `write_heavy`.

The remote model maps addresses with top nibble `0xF` to AXI `SLVERR`; other regions return `OKAY`. This deterministic rule gives the scoreboard and coverage model a reproducible error path.

## Coverage-guided intelligence

Each simulation emits semantic bins such as:

- operation: read/write
- address class: low/mid/high/error
- response: OKAY/SLVERR
- write strobe: full/single/partial
- response latency class
- operation × address class
- operation × response

The Python controller accumulates all bins found so far. A scenario receives reward only for **new** bins. UCB1 balances exploiting productive scenarios against exploring under-tested ones.

This is auditable and reproducible: no external AI API is required. A later research extension can add an LLM or Bayesian optimizer to propose constrained sequences from uncovered bins, while keeping UCB1 as a baseline.

## Questa setup

Set `UVM_HOME` to a UVM source tree that contains `src/uvm_pkg.sv` and `src/uvm_macros.svh`, and make `vlib`, `vlog`, and `vsim` available in `PATH`.

Run an adaptive regression:

```bash
python tools/run_guided.py --iterations 10 --n-txn 50 --reset-state
```

The script compiles once, then creates per-run files under `coverage/`:

- `run_XX_<scenario>.ucdb`
- `run_XX_<scenario>.log`
- `bins_XX_<scenario>.txt`
- `guide_state.json`

To test only the intelligent selector without Questa:

```bash
python -m pytest -q tests/test_coverage_guide.py
```

## Recommended graduation-project phases

1. **Phase 1 — working vertical slice:** run this AXI4-Lite/abstract-UCIe baseline and close its functional/assertion coverage.
2. **Phase 2 — AXI4:** add bursts (`LEN/SIZE/BURST`), IDs, multiple outstanding transactions, ordering rules, and response reordering tests.
3. **Phase 3 — UCIe adapter:** connect a real/supplied UCIe protocol/link BFM or IP and map bridge packets into the permitted streaming/protocol mode.
4. **Phase 4 — intelligent verification study:** compare random regression vs coverage-guided UCB1 using equal simulation budgets; measure coverage-vs-test-count and coverage-vs-time.
5. **Phase 5 — robustness:** fault injection, reset/link-recovery, malformed-response tests, timeout/error propagation, and stress regressions.

## Research metrics

Use at least these four metrics in the report:

- final functional coverage under a fixed test budget
- number of simulations required to reach each coverage threshold
- wall-clock time to coverage closure
- unique bugs/assertion failures found per strategy

Run repeated experiments with several seeds and report mean plus spread; one seed is not enough to support a research conclusion.

## Repository layout

```text
rtl/       DUT, packet package, remote endpoint model
sva/       assertions and cover properties
tb/        UVM interfaces, package, environment, top
tools/     adaptive coverage controller and regression runner
tests/     Python unit tests
docs/      architecture, verification plan, proposal, demo plan
coverage/  generated coverage artifacts
```

## Authoritative protocol references

- Arm, **AMBA AXI and ACE Protocol Specification, IHI 0022** — source for AXI channel and VALID/READY rules.
- UCIe Consortium, **UCIe Specifications** — source for the UCIe architecture and specification releases.

See `docs/REFERENCES.md` for links and the exact scope used by this project.
