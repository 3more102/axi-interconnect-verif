Generated coverage artifacts land here:
- `bins_*.txt`: semantic functional bins hit in one run.
- `run_*.ucdb`: Questa coverage database for one run.
- `guide_state.json`: accumulated coverage-guidance state.
- `run_*.log`: simulator transcripts.
